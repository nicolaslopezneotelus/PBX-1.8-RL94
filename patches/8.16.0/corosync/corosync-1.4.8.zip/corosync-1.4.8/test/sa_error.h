extern int get_sa_error(cs_error_t error, char *str, int len);

extern char *get_sa_error_b (cs_error_t error);

extern char *get_test_output (cs_error_t result, cs_error_t expected);
